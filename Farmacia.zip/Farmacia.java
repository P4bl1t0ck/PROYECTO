import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Farmacia {
    private List<Medicina> inventario = new ArrayList<>();
    private List<Usuario> usuarios = new ArrayList<>();

    public List<Medicina> getInventario() {
        return inventario;
    }

    public List<Usuario> getUsuarios() {
        return usuarios;
    }

    public void agregarMedicina(Medicina medicina) {
        inventario.add(medicina);
    }

    public void agregarUsuario(Usuario usuario) {
        usuarios.add(usuario);
    }

    // Método para cambiar el precio de un producto por ID
    public void cambiarPrecio(int id, double nuevoPrecio) {
        Medicina medicina = buscarMedicinaPorID(id);
        if (medicina != null) {
            medicina.setPrecio(nuevoPrecio);
        } else {
            System.out.println("Producto no encontrado con ID " + id);
        }
    }
    // Método para cambiar el stock de un producto por ID
    public void cambiarStock(int id, int nuevoStock) {
        Medicina medicina = buscarMedicinaPorID(id);
        if (medicina != null) {
            medicina.setStock(nuevoStock);
        } else {
            System.out.println("Producto no encontrado con ID " + id);
        }
    }

    // Método para buscar una medicina por su ID
    private Medicina buscarMedicinaPorID(int id) {
        for (Medicina medicina : inventario) {
            if (medicina.getId() == id) {
                return medicina;
            }
        }
        return null;
    }
    //// metodo para hacer las compras
    ///////////////////////////////////////////////////////////////
    public void  compra(int id,int cant){
        double a=0,b=0;
        String c;
        String respuesta;
        for (Medicina medicina : inventario){
            if (medicina.getPrecio() ==cant){
                /*Medicina medicina = buscarMedicinaPorID(id);*/
                a=medicina.getStock()-cant;
                b=medicina.getPrecio();
                c=medicina.getInfo();
            }
        }
        respuesta="Usted hizo una compra de ["+cant+"] de ["+b+"] por la compra de ";
        System.out.println(respuesta);
    }
}