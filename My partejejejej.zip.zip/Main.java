import org.w3c.dom.ls.LSOutput;

import javax.crypto.spec.PSource;
import javax.swing.UIManager;
import javax.swing.*;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.awt.Color;
import java.awt.Dimension;
/*Ya veremos como actualizarle a ventanas xdxdxdxd*/
public class Main {
    public static void main(String[] args) {
        // Crear usuarios de ejemplo
        Farmacia farmacia = new Farmacia();
        Usuario admin = new Usuario("admin", "adminpass", "admin");
        Usuario cliente = new Usuario("cliente", "clientepass", "cliente");// contraseñas
        // Agregar usuarios a la farmacia

        farmacia.agregarUsuario(admin);
        farmacia.agregarUsuario(cliente);

        // Medicinas predefinidas
        Medicina[] medicinasPredefinidas = {
                new Medicina("Naztizol", 1, 10.5, 50),
                new Medicina("Ibuprofeno", 2, 5.8, 30),
                new Medicina("Jarabe para la tos", 3, 8.75, 40)
        };

        // Agregar medicinas predefinidas al inventario
        for (Medicina medicina : medicinasPredefinidas) {
            farmacia.agregarMedicina(medicina);
        }


        // Momento de Incio de Sesion
        Scanner scanner = new Scanner(System.in);

        String nombreUsuario = JOptionPane.showInputDialog("Nombre de usuario: ");
        String contraseña = JOptionPane.showInputDialog("Contraseña: ");

        Usuario usuarioActual = iniciarSesion(farmacia, nombreUsuario, contraseña);

        if (usuarioActual != null) {
            System.out.println("Inicio de sesión exitoso como " + usuarioActual.getTipo());

            // Menú para el usuario administrador
            if (usuarioActual.getTipo().equals("admin")) {
                menuAdministrador(farmacia, scanner);
            } else {
                menuCliente(farmacia, scanner);
            }
            // Otros menús para diferentes tipos de usuarios podrían ir aquí

        } else {
            System.out.println("Inicio de sesión fallido. Usuario no encontrado o contraseña incorrecta.");
            main(args);// it´ll repeat eveytime the password gets wrong
        }
    }

    // Método para iniciar sesión
    private static Usuario iniciarSesion(Farmacia farmacia, String nombreUsuario, String contraseña) {
        for (Usuario usuario : farmacia.getUsuarios()) {
            if (usuario.getNombreUsuario().equals(nombreUsuario) && usuario.getContraseña().equals(contraseña)) {
                return usuario;
            }
        }
        return null;
    }

    private static void menuCliente(Farmacia farmacia, Scanner scanner) {
        int op;
        do {
            colorDeCliente();
            op = Integer.parseInt(JOptionPane.showInputDialog(null, "----Menu de compras --- \n1. Comprar \n2. Ver Tienda \n0. Salir \n >>>Seleccione una opción: "));
            switch (op) {
                case 1:
                    colorDeCliente();
                    verInvClientes(farmacia);
                    System.out.println("---------------Productos---------------");
                    OperacionesClientes.comprasCliente(farmacia, scanner);
                    break;
                case 2:
                    colorDeCliente();
                    ventanaInventory(farmacia);
                    verInvClientes(farmacia);
                    ofertas(farmacia);
                    break;
                case 0:
                    break;
            }

        } while (op != 0);

    }

    // Menú para el usuario administrador
    private static void menuAdministrador(Farmacia farmacia, Scanner scanner) {
        int opcion;
        do {
            colorDeAdmin();
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null, "\n-----Bienvenido Admin que desea hacer su eminencia-------\n--- Menú de Administrador ---\n 1. Cambiar Precio \n2. Cambiar Stock\n3. Agregar Producto\n4. Ver Inventario\n0. Salir\nSeleccione una opción: \n"));
            //colorDeAdmin();
            switch (opcion) {
                case 1:
                    colorDeAdmin();
                    //verInventario(farmacia);
                    ventanaInventory(farmacia);
                    System.out.println("En caso de perderse el inventario");
                    verInventario(farmacia);
                    OperacionesAdministrador.cambiarPrecio(farmacia, scanner);
                    System.out.println("El inventario esta disponible AKI ");
                    break;
                case 2:
                    colorDeAdmin();
                    ventanaInventory(farmacia);
                    OperacionesAdministrador.cambiarStock(farmacia, scanner);
                    break;
                case 3:
                    colorDeAdmin();
                    ventanaInventory(farmacia);
                    OperacionesAdministrador.compraDeProductos(farmacia, scanner);
                    break;
                case 4:
                    verInventario(farmacia);
                    break;
                case 0:
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
                    menuAdministrador(farmacia, scanner);
            }
        } while (opcion != 0);
    }


    // Métodos para cambiarPrecio, cambiarStock, compraDeProductos, y verInventario aquí...

    // Método para ver el inventario completo
    private static void verInventario(Farmacia farmacia) {
        for (Medicina medicina : farmacia.getInventario()) {
                    System.out.println(medicina.getInfo());
        }
    }
    private static void ventanaInventory(Farmacia farmacia){
        for (Medicina i : farmacia.getInventario()){
            JOptionPane.showInputDialog("Cada elemento del Inventario aparecera abajo uno por uno \n["+i.getInfo()+"]\n");
        }
    }

    //// ver que hay en la tienda
    private static void verInvClientes(Farmacia farmacia) {
        System.out.println("\n--- Tienda ---\n");
        System.out.println("----Bienvenido a la tienda donde esta todo nuestro scuanch----");
        System.out.println("Nota: [Algunas ofertas podrian perderse al momento de carga]");
        for (Medicina medicina : farmacia.getInventario()) {
            System.out.println(medicina.getInformacionClientes());
        }
    }

    private static void ofertas(Farmacia farmacia) {
        JOptionPane.showInputDialog("\n-----¡¡OFERTAS!!----\n");
        for (Medicina medicina : farmacia.getInventario()) {
            JOptionPane.showInputDialog("-----¡¡OFERTAS!!----\n\"Hay ofertas del !-%50-¡ en [\"" + (medicina.getId()) + "\"] - \n[\"" + ((medicina.getPrecio()) / 2) + "\"]");
        }
    }

//Metodo statico que cmabiara el color de las ventanas usando el archivo UImanager.
    private static void colorDeAdmin(){
        UIManager.put("OptionPane.background", new Color(0, 255, 128));
        UIManager.put("Panel.background", new Color(0, 255, 14));

        UIManager.put("OptionPane.minimumSize", new Dimension(400, 400));
        UIManager.put("OptionPane.maximumSize", new Dimension(600, 300));
    }
    private static void colorDeCliente(){
        UIManager.put("OptionPane.background", new Color(19, 245, 180));
        UIManager.put("Panel.background", new Color(7, 3, 3));

        UIManager.put("OptionPane.minimumSize", new Dimension(300, 200));
        UIManager.put("OptionPane.maximumSize", new Dimension(700, 700));
    }

}
// Otros métodos aquí...
