import javax.swing.*;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class OperacionesAdministrador {

    public static void cambiarPrecio(Farmacia farmacia, Scanner scanner) {

        int id = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el ID del producto: "));
        double nuevoPrecio = Double.parseDouble(JOptionPane.showInputDialog(null,"Ingrese el nuevo precio: "));

        farmacia.cambiarPrecio(id, nuevoPrecio);
        JOptionPane.showInputDialog(null,"Precio actualizado correctamente.");
    }

    public static void cambiarStock(Farmacia farmacia, Scanner scanner) {

        int id = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el ID del producto: "));
        int nuevoStock = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese la nueva cantidad de stock: "));

        farmacia.cambiarStock(id, nuevoStock);
        JOptionPane.showInputDialog(null,"Stock actualizado correctamente.");
    }

    public static void compraDeProductos(Farmacia farmacia, Scanner scanner) {
        String i="--- Nuevos Productos ---\nNombre del Producto: \n";
        JOptionPane.showInputDialog(i);
        String nombre = JOptionPane.showInputDialog("Nombre del Producto : ");

        int id = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingrese el ID del producto: "));

        double precio =Double.parseDouble(JOptionPane.showInputDialog(null,"Precio del Producto (con un decimal): "));

        int stock = Integer.parseInt(JOptionPane.showInputDialog(null,"Stock del Producto: "));

        Medicina nuevaMedicina = new Medicina(nombre, id, precio, stock);
        farmacia.agregarMedicina(nuevaMedicina);
        JOptionPane.showInputDialog(null,"Producto agregado correctamente.");

    }
}