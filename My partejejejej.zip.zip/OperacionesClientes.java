import javax.swing.*;
import java.util.Scanner;
public class OperacionesClientes {
    public static void comprasCliente(Farmacia farmacia, Scanner scanner){
        int id = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el ID del producto: "));
        int cant = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad que quiere: "));
        String Nombre=JOptionPane.showInputDialog("Ingrese el Nombre del producto");
        farmacia.compra(id,cant,Nombre);
    }
}