import javax.swing.JOptionPane;

public class FarmaciaApp {

    private int stock; // Stock inicial de medicinas

    public FarmaciaApp(int stockInicial) {
        this.stock = stockInicial;
    }

    public void realizarVenta() {
        try {
            int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de medicinas a vender:"));
            if (cantidad > 0 && cantidad <= stock) {
                stock -= cantidad;
                JOptionPane.showMessageDialog(null, "Venta realizada. Stock actual: " + stock);
            } else {
                JOptionPane.showMessageDialog(null, "Cantidad no válida o insuficiente en stock.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese una cantidad válida.");
        }
    }

    public void realizarCompra() {
        try {
            int cantidad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de medicinas a comprar:"));
            if (cantidad > 0) {
                stock += cantidad;
                JOptionPane.showMessageDialog(null, "Compra realizada. Stock actual: " + stock);
            } else {
                JOptionPane.showMessageDialog(null, "Ingrese una cantidad válida.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese una cantidad válida.");
        }
    }

    public void verStock() {
        JOptionPane.showMessageDialog(null, "Stock actual: " + stock);
    }

    public static void main(String[] args) {
        FarmaciaApp farmacia = new FarmaciaApp(100);

        while (true) {
            int opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    "Seleccione una opción:\n" +
                            "1. Realizar Venta\n" +
                            "2. Realizar Compra\n" +
                            "3. Ver Stock\n" +
                            "4. Salir"));

            switch (opcion) {
                case 1:
                    farmacia.realizarVenta();
                    break;
                case 2:
                    farmacia.realizarCompra();
                    break;
                case 3:
                    farmacia.verStock();
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Saliendo del programa");
                    System.exit(0);
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente nuevamente.");
            }
        }
    }
}