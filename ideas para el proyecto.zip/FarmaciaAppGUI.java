import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FarmaciaAppGUI extends JFrame {

    private int stock; // Stock inicial de medicinas
    private JTextField cantidadTextField;

    public FarmaciaAppGUI(int stockInicial) {
        this.stock = stockInicial;

        // Configuración del marco principal
        setTitle("Farmacia App");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null); // Configuración de un diseño nulo

        // Etiqueta de stock
        JLabel stockLabel = new JLabel("Stock actual: " + stock);
        stockLabel.setBounds(20, 20, 150, 20);
        add(stockLabel);

        // Etiqueta y campo de texto para ingresar cantidad
        JLabel cantidadLabel = new JLabel("Cantidad:");
        cantidadLabel.setBounds(20, 60, 70, 20);
        add(cantidadLabel);

        cantidadTextField = new JTextField();
        cantidadTextField.setBounds(100, 60, 80, 20);
        add(cantidadTextField);

        // Botón de realizar venta
        JButton ventaButton = new JButton("Realizar Venta");
        ventaButton.setBounds(20, 100, 150, 30);
        add(ventaButton);

        ventaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarVenta();
            }
        });

        // Botón de realizar compra
        JButton compraButton = new JButton("Realizar Compra");
        compraButton.setBounds(200, 100, 150, 30);
        add(compraButton);

        compraButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarCompra();
            }
        });

        // Botón de ver stock
        JButton verStockButton = new JButton("Ver Stock");
        verStockButton.setBounds(20, 150, 150, 30);
        add(verStockButton);

        verStockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                verStock();
            }
        });

        // Botón de modificar stock
        JButton modificarStockButton = new JButton("Modificar Stock");
        modificarStockButton.setBounds(200, 150, 150, 30);
        add(modificarStockButton);

        modificarStockButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modificarStock();
            }
        });

        // Mostrar el marco
        setVisible(true);
    }

    private void realizarVenta() {
        try {
            int cantidad = Integer.parseInt(cantidadTextField.getText());
            if (cantidad > 0 && cantidad <= stock) {
                stock -= cantidad;
                JOptionPane.showMessageDialog(this, "Venta realizada. Stock actual: " + stock);
            } else {
                JOptionPane.showMessageDialog(this, "Cantidad no válida o insuficiente en stock.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
        }
    }

    private void realizarCompra() {
        try {
            int cantidad = Integer.parseInt(cantidadTextField.getText());
            if (cantidad > 0) {
                stock += cantidad;
                JOptionPane.showMessageDialog(this, "Compra realizada. Stock actual: " + stock);
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese una cantidad válida.");
        }
    }

    private void verStock() {
        JOptionPane.showMessageDialog(this, "Stock actual: " + stock);
    }

    private void modificarStock() {
        try {
            int nuevoStock = Integer.parseInt(JOptionPane.showInputDialog(this, "Ingrese el nuevo stock:"));
            if (nuevoStock >= 0) {
                stock = nuevoStock;
                JOptionPane.showMessageDialog(this, "Stock modificado. Nuevo stock: " + stock);
            } else {
                JOptionPane.showMessageDialog(this, "Ingrese un valor no negativo.");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingrese un valor numérico válido.");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new FarmaciaAppGUI(100); // Stock inicial de medicinas
            }
        });
    }
}
