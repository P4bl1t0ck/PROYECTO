import javax.swing.JOptionPane;

public class FarmaciaMenu {

    public static void main(String[] args) {
        int stock = 100; // Cantidad inicial de productos en stock

        while (true) {
            // Mostrar el menú de opciones
            String[] opciones = {"Realizar venta", "Ver stock", "Salir"};
            int seleccion = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción:",
                    "Control de Venta - Farmacia",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    opciones,
                    opciones[0]);

            // Realizar acciones según la opción seleccionada
            switch (seleccion) {
                case 0:
                    // Realizar venta
                    int cantidadVenta = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad a vender:"));
                    if (cantidadVenta <= stock && cantidadVenta > 0) {
                        stock -= cantidadVenta;
                        JOptionPane.showMessageDialog(null, "Venta realizada. Stock actual: " + stock);
                    } else {
                        JOptionPane.showMessageDialog(null, "Cantidad no válida o insuficiente en stock.");
                    }
                    break;
                case 1:
                    // Ver stock
                    JOptionPane.showMessageDialog(null, "Stock actual: " + stock);
                    break;
                case 2:
                    // Salir del programa
                    JOptionPane.showMessageDialog(null, "Saliendo del programa");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente nuevamente.");
            }
        }
    }
}
