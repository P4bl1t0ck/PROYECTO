import javax.swing.JOptionPane;

public class MenuConJOptionPane {

    public static void main(String[] args) {
        while (true) {
            // Mostrar el menú con opciones
            String[] opciones = {"Abrir ventana", "Salir"};
            int seleccion = JOptionPane.showOptionDialog(
                    null,
                    "Seleccione una opción:",
                    "Menú con JOptionPane",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.PLAIN_MESSAGE,
                    null,
                    opciones,
                    opciones[0]);

            // Realizar acciones según la opción seleccionada
            switch (seleccion) {
                case 0:
                    JOptionPane.showMessageDialog(null, "Ventana abierta");
                    break;
                case 1:
                    JOptionPane.showMessageDialog(null, "Saliendo del programa");
                    System.exit(0);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción no válida. Intente nuevamente.");
            }
        }
    }
}