import java.util.Scanner;

public class SistemaDeLogin {

    private static final String USUARIO_ADMIN = "admin";
    private static final String CONTRASENA_ADMIN = "admin123";

    private static final String USUARIO_USUARIO = "usuario";
    private static final String CONTRASENA_USUARIO = "usuario123";

    private boolean sesionIniciada = false;

    public void iniciarSesion() {
        Scanner scanner = new Scanner(System.in);

        while (!sesionIniciada) {
            System.out.println("Ingrese su nombre de usuario:");
            String usuario = scanner.nextLine();
            System.out.println("Ingrese su contraseña:");
            String contrasena = scanner.nextLine();

            if (iniciarSesionComoAdmin(usuario, contrasena)) {
                System.out.println("¡Bienvenido, Administrador!");
                sesionIniciada = true;
                ejecutarOpcionesAdmin();
            } else if (iniciarSesionComoUsuario(usuario, contrasena)) {
                System.out.println("¡Bienvenido, Usuario!");
                sesionIniciada = true;
                ejecutarOpcionesUsuario();
            } else {
                System.out.println("Credenciales incorrectas. Intente nuevamente.");
            }
        }
    }

    private boolean iniciarSesionComoAdmin(String usuario, String contrasena) {
        return usuario.equals(USUARIO_ADMIN) && contrasena.equals(CONTRASENA_ADMIN);
    }

    private boolean iniciarSesionComoUsuario(String usuario, String contrasena) {
        return usuario.equals(USUARIO_USUARIO) && contrasena.equals(CONTRASENA_USUARIO);
    }

    private void ejecutarOpcionesAdmin() {
        // Aquí se pueden agregar las opciones y acciones específicas para el administrador.
        System.out.println("Opciones del Administrador:");
        System.out.println("1. Realizar modificaciones");
        System.out.println("2. Cerrar sesión");
    }

    private void ejecutarOpcionesUsuario() {
        // Aquí se pueden agregar las opciones y acciones específicas para el usuario.
        System.out.println("Opciones del Usuario:");
        System.out.println("1. Realizar tareas de usuario");
        System.out.println("2. Cerrar sesión");
    }

    public static void main(String[] args) {
        SistemaDeLogin sistema = new SistemaDeLogin();
        sistema.iniciarSesion();
    }
}